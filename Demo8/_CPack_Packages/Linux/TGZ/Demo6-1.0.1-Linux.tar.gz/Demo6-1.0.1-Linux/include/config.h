/* #undef HAVE_POW */
#define Demo_VERSION_MAJOR 1
#define Demo_VERSION_MINOR 0
